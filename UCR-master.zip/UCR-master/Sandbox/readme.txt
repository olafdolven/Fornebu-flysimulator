This folder contains miscellaneous test harnesses and stuff.
It's contents are not required to run UCR.