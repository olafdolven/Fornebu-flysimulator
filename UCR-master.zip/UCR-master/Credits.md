UCR runs using Autohotkey_H v1  (ANSI) by HotkeyIt, based upon AHK_L by Lexikos  
http://hotkeyit.github.io/v2/  
UCR WILL NOT RUN USING VANILLA AUTOHOTKEY ("AHK_L")  

JSON serialization (for dumping settings to disk) by CoCo's JSON Lib  
For now, UCR uses my fork (Very minor tweak to fix AHK_H compatibility): https://github.com/evilC/AutoHotkey-JSON/  
Coco's JSON Lib - http://autohotkey.com/boards/viewtopic.php?f=6&t=627  

Joystick OEM names are pulled using Blijbol's JoystickOEMName.dll  
http://gamemaker.blijbol.nl/en/joystickoemname  
