UCR Readme.txt

UCR Ships as a standalone application. It does not require any dependencies, or installation, to run.
Simply create a folder for UCR and place all of the files from this zip into the folder.
Then simply double-click UCR.exe to run.

For more information, documentation, etc, please see the GitHub page at:
https://github.com/evilC/UCR