This is a client to connect Microsoft Flight Simulator to Flight Events.

More information on how to use Flight Events is available at https://events.flighttracker.tech/.