package com.flightsim.fsuipc;
/*
Copyright 2002 Mark Burton
*/



public class FSEngine4 extends FSEngine
	{
	public FSEngine4()
	{
	super();
	iMixAddress=0xa58;
	iStartAddress=0xa5a;
	iCombustionAddress=0xa5c;
	}
	}
