/*
Copyright 2003 Mark Burton
Amended 2020 for 64bit by Paul Henty 
 */
package com.flightsim.fsuipc;

/**
 * Wrapper class for fsuipc_java64.dll
 *
 * @author Mark Burton (Amended by Paul Henty for 64bit)
 */
public class fsuipc_wrapper {

    public static final int SIM_ANY = 0;
    public static final int SIM_FS98 = 1;
    public static final int SIM_FS2K = 2;
    public static final int SIM_CFS2 = 3;
    public static final int SIM_CFS1 = 4;
    public static final int SIM_FS2K2 = 6;
    public static final int SIM_FS2K4 = 7;
    public static final int SIM_FSX = 8;
    public static final int SIM_ESP = 9;
    public static final int SIM_P3D = 10;
    public static final int SIM_FSW = 11;
    public static final int SIM_P3DX64 = 12;

    public static final int FSUIPC_ERR_OK = 0; // No error
    public static final int FSUIPC_ERR_OPEN = 1; // Attempt to Open() when connection is already open.	   
    public static final int FSUIPC_ERR_NOFS = 2; // Cannot link to FSUIPC or WideClient
    public static final int FSUIPC_ERR_REGMSG = 3; // Failed to Register common message with Windows
    public static final int FSUIPC_ERR_ATOM = 4; // Failed to create Atom for mapping filename
    public static final int FSUIPC_ERR_MAP = 5; // Failed to create a file mapping object
    public static final int FSUIPC_ERR_VIEW = 6; // Failed to open a view to the file map
    public static final int FSUIPC_ERR_VERSION = 7; // Incorrect version of FSUIPC, or not FSUIPC.
    public static final int FSUIPC_ERR_WRONGFS = 8; // Flight Sim is not version requested by this application.
    public static final int FSUIPC_ERR_NOTOPEN = 9; // Attempted to call Process() but the FSUIPC link has not been opened.
    public static final int FSUIPC_ERR_NODATA = 10; // Call cannot execute: no requests accumulated
    public static final int FSUIPC_ERR_TIMEOUT = 11; // IPC SendMessage timed out (all retries)
    public static final int FSUIPC_ERR_SENDMSG = 12; // IPC SendMessage failed (all retries)
    public static final int FSUIPC_ERR_DATA = 13; // IPC request contains bad data        
    public static final int FSUIPC_ERR_RUNNING = 14; // Wrong version of FSUIPC.  Can also occur if running on WideClient but FSUIPC is not running on server.
    public static final int FSUIPC_ERR_SIZE = 15; // Read or Write request cannot be added to the shared memory file as the file is full.

    /**
     * Automatically load the dll
     */
    static {
        // load library
        System.loadLibrary("fsuipc_java64");
    }

    /**
     * Connect to FS.
     *
     * @param aFlightSim Version of flightsim to try and connect to.
     * @return 0 if connection failed
     */
    public static synchronized native int Open(int aFlightSim);

    /**
     * Close the connection
     */
    public static synchronized native void Close();

    /**
     * Read bytes from FS
     */
    public static synchronized native void ReadData(int aOffset, int aCount, byte[] aData);

    /**
     * Write byte to FS
     */
    public static synchronized native void WriteData(int aOffset, int aCount, byte[] aData);

    /**
     * Process the commands
     */
    public static synchronized native void Process();

    /**
     * Returns the last error code (See fsuipc_wrapper.FSUIPC_ERR variables)
     */
    public static synchronized native int GetResult();
}
