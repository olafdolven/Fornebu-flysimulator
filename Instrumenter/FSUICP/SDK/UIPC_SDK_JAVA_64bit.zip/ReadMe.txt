==========================
64 Bit Java SDK for FSUIPC
==========================
---------
Credits:
---------

Based on the 32bit Java FSUIPC SDK by Mark Burton 2003
Modified for 64bit by Paul Henty 2020

-----------------
In this package:
-----------------

fsuipc64.jar      - Reference this in your java application

fsuipc_java.dll   - C Wrapper used by fsuipc64.jar. 
                    This needs to be placed in the same folder as your
                    final application JAR file, or in the current PATH.

api.doc
api.pdf           - Documentation from the original 32bit Java SDK

FSUIPCTest.jar    - Compiled test application that will connect to the sim
                    and report various information. Run this from the 
                    command console: 
                        java -jar FSUIPCTest.jar

FSUIPCTest.bat    - A batch file that can double-clicked from the file
                    explorer that runs FSUIPCTest.jar in a console.

Source\CWrapper   - Source code for the C DLL used by fsuip64.jar.
                    This is a Visual Studio 2019 solution.
                    You will need to modify the preprocessor paths 
                    to point at your Java SDK or JDK folder so that the 
                    JNI headers are picked up.

Source\fsuipc64   - Source code for the fsuipc64.jar file.
                    This is a NetBeans project but the .java files in /src
                    can be used in any development environment.

Source\FSUIPCTest - Example code. Source code for the test project
	            This is a NetBeans project but the .java files in /src
                    can be used in any development environment.

------------------------------------------------------
Upgrading your application from the original 32bit SDK
------------------------------------------------------

The API is exactly the same. 
Just reference the fsuipc64.jar file instead of fsuipc.jar.
Include the fsuipc_java64.dll files instead of the fsuipcjava.dll file.

Minor additions to the API are:

1. New SIM_ version constants up to P3D 64 bit.

2. New function GetResult() which returns an int. This is useful for 
   getting the error code after a connect() or process() call fails.

3. New FSUIPC_ERR constants that tell you what the error codes mean 
   from GetResult().